import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\InsuranceController::index
 * @see app/Http/Controllers/InsuranceController.php:18
 * @route '/insurances'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/insurances',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\InsuranceController::index
 * @see app/Http/Controllers/InsuranceController.php:18
 * @route '/insurances'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\InsuranceController::index
 * @see app/Http/Controllers/InsuranceController.php:18
 * @route '/insurances'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\InsuranceController::index
 * @see app/Http/Controllers/InsuranceController.php:18
 * @route '/insurances'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\InsuranceController::index
 * @see app/Http/Controllers/InsuranceController.php:18
 * @route '/insurances'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\InsuranceController::index
 * @see app/Http/Controllers/InsuranceController.php:18
 * @route '/insurances'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\InsuranceController::index
 * @see app/Http/Controllers/InsuranceController.php:18
 * @route '/insurances'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\InsuranceController::store
 * @see app/Http/Controllers/InsuranceController.php:31
 * @route '/insurances'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/insurances',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\InsuranceController::store
 * @see app/Http/Controllers/InsuranceController.php:31
 * @route '/insurances'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\InsuranceController::store
 * @see app/Http/Controllers/InsuranceController.php:31
 * @route '/insurances'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\InsuranceController::store
 * @see app/Http/Controllers/InsuranceController.php:31
 * @route '/insurances'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\InsuranceController::store
 * @see app/Http/Controllers/InsuranceController.php:31
 * @route '/insurances'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\InsuranceController::update
 * @see app/Http/Controllers/InsuranceController.php:53
 * @route '/insurances/{insurance}'
 */
export const update = (args: { insurance: number | { id: number } } | [insurance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/insurances/{insurance}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\InsuranceController::update
 * @see app/Http/Controllers/InsuranceController.php:53
 * @route '/insurances/{insurance}'
 */
update.url = (args: { insurance: number | { id: number } } | [insurance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { insurance: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { insurance: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    insurance: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        insurance: typeof args.insurance === 'object'
                ? args.insurance.id
                : args.insurance,
                }

    return update.definition.url
            .replace('{insurance}', parsedArgs.insurance.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\InsuranceController::update
 * @see app/Http/Controllers/InsuranceController.php:53
 * @route '/insurances/{insurance}'
 */
update.put = (args: { insurance: number | { id: number } } | [insurance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\InsuranceController::update
 * @see app/Http/Controllers/InsuranceController.php:53
 * @route '/insurances/{insurance}'
 */
update.patch = (args: { insurance: number | { id: number } } | [insurance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\InsuranceController::update
 * @see app/Http/Controllers/InsuranceController.php:53
 * @route '/insurances/{insurance}'
 */
    const updateForm = (args: { insurance: number | { id: number } } | [insurance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\InsuranceController::update
 * @see app/Http/Controllers/InsuranceController.php:53
 * @route '/insurances/{insurance}'
 */
        updateForm.put = (args: { insurance: number | { id: number } } | [insurance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\InsuranceController::update
 * @see app/Http/Controllers/InsuranceController.php:53
 * @route '/insurances/{insurance}'
 */
        updateForm.patch = (args: { insurance: number | { id: number } } | [insurance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\InsuranceController::destroy
 * @see app/Http/Controllers/InsuranceController.php:75
 * @route '/insurances/{insurance}'
 */
export const destroy = (args: { insurance: number | { id: number } } | [insurance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/insurances/{insurance}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\InsuranceController::destroy
 * @see app/Http/Controllers/InsuranceController.php:75
 * @route '/insurances/{insurance}'
 */
destroy.url = (args: { insurance: number | { id: number } } | [insurance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { insurance: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { insurance: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    insurance: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        insurance: typeof args.insurance === 'object'
                ? args.insurance.id
                : args.insurance,
                }

    return destroy.definition.url
            .replace('{insurance}', parsedArgs.insurance.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\InsuranceController::destroy
 * @see app/Http/Controllers/InsuranceController.php:75
 * @route '/insurances/{insurance}'
 */
destroy.delete = (args: { insurance: number | { id: number } } | [insurance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\InsuranceController::destroy
 * @see app/Http/Controllers/InsuranceController.php:75
 * @route '/insurances/{insurance}'
 */
    const destroyForm = (args: { insurance: number | { id: number } } | [insurance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\InsuranceController::destroy
 * @see app/Http/Controllers/InsuranceController.php:75
 * @route '/insurances/{insurance}'
 */
        destroyForm.delete = (args: { insurance: number | { id: number } } | [insurance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const InsuranceController = { index, store, update, destroy }

export default InsuranceController