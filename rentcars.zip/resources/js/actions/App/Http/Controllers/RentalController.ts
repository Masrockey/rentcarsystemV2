import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\RentalController::index
 * @see app/Http/Controllers/RentalController.php:22
 * @route '/rentals'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/rentals',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RentalController::index
 * @see app/Http/Controllers/RentalController.php:22
 * @route '/rentals'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RentalController::index
 * @see app/Http/Controllers/RentalController.php:22
 * @route '/rentals'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\RentalController::index
 * @see app/Http/Controllers/RentalController.php:22
 * @route '/rentals'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\RentalController::index
 * @see app/Http/Controllers/RentalController.php:22
 * @route '/rentals'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\RentalController::index
 * @see app/Http/Controllers/RentalController.php:22
 * @route '/rentals'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\RentalController::index
 * @see app/Http/Controllers/RentalController.php:22
 * @route '/rentals'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\RentalController::store
 * @see app/Http/Controllers/RentalController.php:40
 * @route '/rentals'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/rentals',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RentalController::store
 * @see app/Http/Controllers/RentalController.php:40
 * @route '/rentals'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RentalController::store
 * @see app/Http/Controllers/RentalController.php:40
 * @route '/rentals'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\RentalController::store
 * @see app/Http/Controllers/RentalController.php:40
 * @route '/rentals'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RentalController::store
 * @see app/Http/Controllers/RentalController.php:40
 * @route '/rentals'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\RentalController::update
 * @see app/Http/Controllers/RentalController.php:80
 * @route '/rentals/{rental}'
 */
export const update = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/rentals/{rental}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\RentalController::update
 * @see app/Http/Controllers/RentalController.php:80
 * @route '/rentals/{rental}'
 */
update.url = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rental: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rental: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rental: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rental: typeof args.rental === 'object'
                ? args.rental.id
                : args.rental,
                }

    return update.definition.url
            .replace('{rental}', parsedArgs.rental.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RentalController::update
 * @see app/Http/Controllers/RentalController.php:80
 * @route '/rentals/{rental}'
 */
update.put = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\RentalController::update
 * @see app/Http/Controllers/RentalController.php:80
 * @route '/rentals/{rental}'
 */
update.patch = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\RentalController::update
 * @see app/Http/Controllers/RentalController.php:80
 * @route '/rentals/{rental}'
 */
    const updateForm = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RentalController::update
 * @see app/Http/Controllers/RentalController.php:80
 * @route '/rentals/{rental}'
 */
        updateForm.put = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\RentalController::update
 * @see app/Http/Controllers/RentalController.php:80
 * @route '/rentals/{rental}'
 */
        updateForm.patch = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\RentalController::destroy
 * @see app/Http/Controllers/RentalController.php:128
 * @route '/rentals/{rental}'
 */
export const destroy = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/rentals/{rental}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\RentalController::destroy
 * @see app/Http/Controllers/RentalController.php:128
 * @route '/rentals/{rental}'
 */
destroy.url = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rental: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rental: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rental: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rental: typeof args.rental === 'object'
                ? args.rental.id
                : args.rental,
                }

    return destroy.definition.url
            .replace('{rental}', parsedArgs.rental.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RentalController::destroy
 * @see app/Http/Controllers/RentalController.php:128
 * @route '/rentals/{rental}'
 */
destroy.delete = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\RentalController::destroy
 * @see app/Http/Controllers/RentalController.php:128
 * @route '/rentals/{rental}'
 */
    const destroyForm = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RentalController::destroy
 * @see app/Http/Controllers/RentalController.php:128
 * @route '/rentals/{rental}'
 */
        destroyForm.delete = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const RentalController = { index, store, update, destroy }

export default RentalController