import DashboardController from './DashboardController'
import UserController from './UserController'
import CustomerController from './CustomerController'
import CarController from './CarController'
import DriverController from './DriverController'
import BookingController from './BookingController'
import PaymentController from './PaymentController'
import ServiceController from './ServiceController'
import InsuranceController from './InsuranceController'
import VehicleTaxController from './VehicleTaxController'
import RentalController from './RentalController'
import ReportController from './ReportController'
import Settings from './Settings'
const Controllers = {
    DashboardController: Object.assign(DashboardController, DashboardController),
UserController: Object.assign(UserController, UserController),
CustomerController: Object.assign(CustomerController, CustomerController),
CarController: Object.assign(CarController, CarController),
DriverController: Object.assign(DriverController, DriverController),
BookingController: Object.assign(BookingController, BookingController),
PaymentController: Object.assign(PaymentController, PaymentController),
ServiceController: Object.assign(ServiceController, ServiceController),
InsuranceController: Object.assign(InsuranceController, InsuranceController),
VehicleTaxController: Object.assign(VehicleTaxController, VehicleTaxController),
RentalController: Object.assign(RentalController, RentalController),
ReportController: Object.assign(ReportController, ReportController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers