import { Head, Link, router, useForm, usePage } from '@inertiajs/react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogFooter
} from '@/components/ui/dialog';
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { useState, useEffect } from 'react';
import { Plus, User, Key, UserCheck, Calendar, DollarSign, Settings, Car } from 'lucide-react';
import { index as bookingsIndex } from '@/routes/bookings';

type Customer = {
    id: number;
    name: string;
};

type CarType = {
    id: number;
    name: string;
    plate_number: string;
    status: string;
    daily_price: string | null;
    weekly_price: string | null;
    monthly_price: string | null;
};

type UserType = {
    id: number;
    name: string;
    role: string;
};

type Booking = {
    id: number;
    customer_id: number;
    customer?: Customer;
    car_type: string;
    car_id: number | null;
    car?: CarType;
    peluncur_id: number | null;
    peluncur?: UserType;
    petugas_cuci_id: number | null;
    petugas_cuci?: UserType;
    booking_date: string;
    return_date: string | null;
    payment_method: 'Cash' | 'Transfer' | 'DP';
    payment_status: 'Pending' | 'Paid' | 'Down Payment';
    amount: number;
    status: 'Pending' | 'Confirmed' | 'On Trip' | 'Returned' | 'Completed';
};

type Props = {
    bookings: Booking[];
    customers: Customer[];
    cars: CarType[];
    readyCars: CarType[];
    peluncurOfficers: UserType[];
    washOfficers: UserType[];
};

export default function BookingsIndex({
    bookings,
    customers,
    cars,
    readyCars,
    peluncurOfficers,
    washOfficers
}: Props) {
    const { auth } = usePage().props;
    const user = auth?.user as any;
    const roles: string[] = user?.roles || [];
    const hasRole = (r: string) => roles.includes(r);

    const [isCreateOpen, setIsCreateOpen] = useState(false);
    const [isAssignOpen, setIsAssignOpen] = useState(false);
    const [washConfirmId, setWashConfirmId] = useState<number | null>(null);
    const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);

    const { data: createData, setData: setCreateData, post: postCreate, reset: resetCreate, processing: processingCreate, errors: errorsCreate } = useForm({
        customer_id: '',
        car_type: '',
        booking_date: '',
        return_date: '',
        payment_method: 'Cash',
        payment_status: 'Pending',
        amount: '',
    });

    const { data: assignData, setData: setAssignData, put: putAssign, processing: processingAssign } = useForm({
        car_id: '',
        peluncur_id: '',
        petugas_cuci_id: '',
    });

    useEffect(() => {
        if (!createData.car_type) {
            return;
        }

        const selected = readyCars.find(c => c.name === createData.car_type);
        if (!selected) return;

        const daily = selected.daily_price ? parseFloat(selected.daily_price) : 0;
        const weekly = selected.weekly_price ? parseFloat(selected.weekly_price) : 0;
        const monthly = selected.monthly_price ? parseFloat(selected.monthly_price) : 0;

        if (!createData.booking_date || !createData.return_date) {
            setCreateData('amount', daily.toString());
            return;
        }

        const start = new Date(createData.booking_date);
        const end = new Date(createData.return_date);
        if (isNaN(start.getTime()) || isNaN(end.getTime()) || end < start) {
            setCreateData('amount', daily.toString());
            return;
        }

        const diffTime = Math.abs(end.getTime() - start.getTime());
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        const days = diffDays === 0 ? 1 : diffDays;

        let total = 0;
        let remainingDays = days;

        if (monthly > 0 && remainingDays >= 30) {
            const months = Math.floor(remainingDays / 30);
            total += months * monthly;
            remainingDays %= 30;
        }

        if (weekly > 0 && remainingDays >= 7) {
            const weeks = Math.floor(remainingDays / 7);
            total += weeks * weekly;
            remainingDays %= 7;
        }

        total += remainingDays * daily;

        setCreateData('amount', total.toString());
    }, [createData.car_type, createData.booking_date, createData.return_date]);

    const openCreateDialog = () => {
        resetCreate();
        if (customers.length > 0) {
            setCreateData('customer_id', customers[0].id.toString());
        }
        setIsCreateOpen(true);
    };

    const openAssignDialog = (booking: Booking) => {
        setSelectedBooking(booking);
        setAssignData({
            car_id: booking.car_id ? booking.car_id.toString() : '',
            peluncur_id: booking.peluncur_id ? booking.peluncur_id.toString() : '',
            petugas_cuci_id: booking.petugas_cuci_id ? booking.petugas_cuci_id.toString() : '',
        });
        setIsAssignOpen(true);
    };

    const handleCreateSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        postCreate('/bookings', {
            onSuccess: () => {
                setIsCreateOpen(false);
                resetCreate();
            },
        });
    };

    const handleAssignSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (selectedBooking) {
            putAssign(`/bookings/${selectedBooking.id}`, {
                onSuccess: () => {
                    setIsAssignOpen(false);
                },
            });
        }
    };

    const handleCompleteWash = (bookingId: number) => {
        setWashConfirmId(bookingId);
    };

    const formatCurrency = (val: number) => {
        return new Intl.NumberFormat('id-ID', {
            style: 'currency',
            currency: 'IDR',
            maximumFractionDigits: 0
        }).format(val);
    };

    const getStatusColor = (status: string) => {
        switch (status) {
            case 'Pending':
                return 'bg-yellow-500/15 text-yellow-600 dark:text-yellow-400 border-yellow-500/25';
            case 'Confirmed':
                return 'bg-blue-500/15 text-blue-600 dark:text-blue-400 border-blue-500/25';
            case 'On Trip':
                return 'bg-purple-500/15 text-purple-600 dark:text-purple-400 border-purple-500/25';
            case 'Returned':
                return 'bg-orange-500/15 text-orange-600 dark:text-orange-400 border-orange-500/25';
            case 'Completed':
                return 'bg-green-500/15 text-green-600 dark:text-green-400 border-green-500/25';
            default:
                return 'bg-neutral-500/15 text-neutral-600 dark:text-neutral-400 border-neutral-500/25';
        }
    };

    const getPaymentStatusColor = (status: string) => {
        switch (status) {
            case 'Pending':
                return 'bg-red-500/15 text-red-600 border-red-500/25';
            case 'Paid':
                return 'bg-green-500/15 text-green-600 border-green-500/25';
            case 'Down Payment':
                return 'bg-blue-500/15 text-blue-600 border-blue-500/25';
            default:
                return '';
        }
    };

    return (
        <>
            <Head title="Rent Car Bookings" />
            <div className="flex flex-1 flex-col gap-6 p-6">
                <div className="flex items-center justify-between">
                    <div className="flex flex-col gap-1">
                        <h1 className="text-3xl font-bold tracking-tight">Rental Bookings</h1>
                        <p className="text-muted-foreground">Monitor car bookings, dispatch staff, and wash updates.</p>
                    </div>
                    {(hasRole('Marketing') || hasRole('Admin')) && (
                        <Button onClick={openCreateDialog} className="flex items-center gap-1">
                            <Plus className="h-4 w-4" /> New Booking
                        </Button>
                    )}
                </div>

                <Card>
                    <CardHeader>
                        <CardTitle>Rent Car Bookings</CardTitle>
                    </CardHeader>
                    <CardContent>
                        {/* Mobile Cards View */}
                        <div className="space-y-3 md:hidden">
                            {bookings.length === 0 ? (
                                <div className="text-center py-8 text-muted-foreground text-sm">
                                    No bookings found.
                                </div>
                            ) : (
                                bookings.map((booking) => (
                                    <div key={booking.id} className="flex flex-col gap-2 p-4 rounded-lg border bg-card text-card-foreground shadow-xs">
                                        <div className="flex items-center justify-between">
                                            <span className="font-semibold text-sm">{booking.customer?.name}</span>
                                            <Badge variant="outline" className={getStatusColor(booking.status)}>
                                                {booking.status}
                                            </Badge>
                                        </div>
                                        <div className="text-xs text-muted-foreground space-y-1">
                                            <div><span className="font-semibold text-foreground">Requested Car:</span> {booking.car_type}</div>
                                            <div><span className="font-semibold text-foreground">Assigned Fleet:</span> {booking.car ? `${booking.car.name} (${booking.car.plate_number})` : <span className="italic text-muted-foreground text-xs">Unallocated</span>}</div>
                                            <div><span className="font-semibold text-foreground">Dates:</span> Start: {booking.booking_date} {booking.return_date ? `| End: ${booking.return_date}` : ''}</div>
                                            <div><span className="font-semibold text-foreground">Payment:</span> {formatCurrency(booking.amount)} ({booking.payment_status} via {booking.payment_method})</div>
                                            <div><span className="font-semibold text-foreground">Staff Duties:</span> Peluncur: {booking.peluncur?.name ?? 'None'}, Wash: {booking.petugas_cuci?.name ?? 'None'}</div>
                                        </div>
                                        <div className="flex justify-end gap-2 pt-2 border-t mt-1">
                                            {hasRole('Admin') && (
                                                <Button
                                                    variant="outline"
                                                    size="sm"
                                                    className="flex items-center gap-1 h-8 text-xs"
                                                    onClick={() => openAssignDialog(booking)}
                                                >
                                                    <Settings className="h-3 w-3" /> Allocate
                                                </Button>
                                            )}

                                            {hasRole('Peluncur') && booking.status === 'Confirmed' && (
                                                <Link href={`/bookings/${booking.id}/checklist`}>
                                                    <Button size="sm" className="h-8 text-xs">Deliver Car</Button>
                                                </Link>
                                            )}

                                            {hasRole('Peluncur') && booking.status === 'On Trip' && (
                                                <Link href={`/bookings/${booking.id}/checklist`}>
                                                    <Button size="sm" variant="secondary" className="h-8 text-xs">Return Car</Button>
                                                </Link>
                                            )}

                                            {(hasRole('Petugas Cuci') || hasRole('Admin')) && booking.status === 'Returned' && (
                                                <Button
                                                    size="sm"
                                                    variant="default"
                                                    className="bg-green-600 hover:bg-green-700 text-white h-8 text-xs"
                                                    onClick={() => handleCompleteWash(booking.id)}
                                                >
                                                    Wash Complete
                                                </Button>
                                            )}
                                        </div>
                                    </div>
                                ))
                            )}
                        </div>

                        {/* Desktop Table View */}
                        <div className="hidden md:block relative overflow-x-auto rounded-lg border">
                            <table className="w-full text-left text-sm">
                                <thead className="bg-muted text-xs uppercase text-muted-foreground">
                                    <tr>
                                        <th className="px-4 py-3">Customer</th>
                                        <th className="px-4 py-3">Requested Car</th>
                                        <th className="px-4 py-3">Assigned Fleet</th>
                                        <th className="px-4 py-3">Dates</th>
                                        <th className="px-4 py-3">Payment</th>
                                        <th className="px-4 py-3">Staff Duties</th>
                                        <th className="px-4 py-3">Status</th>
                                        <th className="px-4 py-3 text-right">Actions</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y">
                                    {bookings.length === 0 ? (
                                        <tr>
                                            <td colSpan={8} className="px-4 py-8 text-center text-muted-foreground">
                                                No bookings found.
                                            </td>
                                        </tr>
                                    ) : (
                                        bookings.map((booking) => (
                                            <tr key={booking.id} className="hover:bg-muted/50">
                                                <td className="px-4 py-4">
                                                    <span className="font-semibold">{booking.customer?.name}</span>
                                                </td>
                                                <td className="px-4 py-4">{booking.car_type}</td>
                                                <td className="px-4 py-4 font-mono font-medium">
                                                    {booking.car ? `${booking.car.name} (${booking.car.plate_number})` : <span className="text-muted-foreground text-xs italic">Unallocated</span>}
                                                </td>
                                                <td className="px-4 py-4 text-xs whitespace-nowrap">
                                                    <div>Start: {booking.booking_date}</div>
                                                    {booking.return_date && <div>End: {booking.return_date}</div>}
                                                </td>
                                                <td className="px-4 py-4">
                                                    <div className="font-medium text-xs">{formatCurrency(booking.amount)}</div>
                                                    <Badge variant="outline" className={`mt-1 text-[10px] ${getPaymentStatusColor(booking.payment_status)}`}>
                                                        {booking.payment_status} ({booking.payment_method})
                                                    </Badge>
                                                </td>
                                                <td className="px-4 py-4 text-xs">
                                                    <div>Peluncur: {booking.peluncur ? booking.peluncur.name : <span className="text-muted-foreground italic">None</span>}</div>
                                                    <div className="mt-1">Wash: {booking.petugas_cuci ? booking.petugas_cuci.name : <span className="text-muted-foreground italic">None</span>}</div>
                                                </td>
                                                <td className="px-4 py-4">
                                                    <Badge variant="outline" className={getStatusColor(booking.status)}>
                                                        {booking.status}
                                                    </Badge>
                                                </td>
                                                <td className="px-4 py-4 text-right whitespace-nowrap">
                                                    <div className="flex items-center justify-end gap-2">
                                                        {hasRole('Admin') && (
                                                            <Button
                                                                variant="outline"
                                                                size="sm"
                                                                className="flex items-center gap-1"
                                                                onClick={() => openAssignDialog(booking)}
                                                            >
                                                                <Settings className="h-3.5 w-3.5" /> Allocate
                                                            </Button>
                                                        )}

                                                        {hasRole('Peluncur') && booking.status === 'Confirmed' && (
                                                            <Link href={`/bookings/${booking.id}/checklist`}>
                                                                <Button size="sm">Deliver Car</Button>
                                                            </Link>
                                                        )}

                                                        {hasRole('Peluncur') && booking.status === 'On Trip' && (
                                                            <Link href={`/bookings/${booking.id}/checklist`}>
                                                                <Button size="sm" variant="secondary">Return Car</Button>
                                                            </Link>
                                                        )}

                                                        {(hasRole('Petugas Cuci') || hasRole('Admin')) && booking.status === 'Returned' && (
                                                            <Button
                                                                size="sm"
                                                                variant="default"
                                                                className="bg-green-600 hover:bg-green-700 text-white"
                                                                onClick={() => handleCompleteWash(booking.id)}
                                                            >
                                                                Wash Complete
                                                            </Button>
                                                        )}
                                                    </div>
                                                </td>
                                            </tr>
                                        ))
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </CardContent>
                </Card>

                {/* CREATE BOOKING DIALOG */}
                <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
                    <DialogContent className="max-w-md">
                        <DialogHeader>
                            <h2 className="text-lg font-semibold">New Rental Booking</h2>
                        </DialogHeader>
                        <form onSubmit={handleCreateSubmit} className="space-y-4 py-2">
                            <div className="space-y-1">
                                <Label htmlFor="customer_id">Select Customer</Label>
                                <Select
                                    value={createData.customer_id}
                                    onValueChange={(val) => setCreateData('customer_id', val)}
                                >
                                    <SelectTrigger>
                                        <SelectValue placeholder="Choose a customer" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {customers.map((c) => (
                                            <SelectItem key={c.id} value={c.id.toString()}>{c.name}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>

                            <div className="space-y-1">
                                <Label htmlFor="car_type">Requested Car Type</Label>
                                <Select
                                    value={createData.car_type}
                                    onValueChange={(val) => setCreateData('car_type', val)}
                                >
                                    <SelectTrigger id="car_type">
                                        <SelectValue placeholder="Pilih kendaraan yang tersedia..." />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {readyCars.length === 0 ? (
                                            <div className="px-3 py-2 text-xs text-muted-foreground">Tidak ada kendaraan Ready.</div>
                                        ) : readyCars.map((c) => (
                                            <SelectItem key={c.id} value={c.name}>
                                                <span>{c.name}</span>
                                                <span className="ml-2 font-mono text-xs text-muted-foreground">({c.plate_number})</span>
                                                {c.daily_price && (
                                                    <span className="ml-2 text-xs text-green-600">
                                                        {new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(Number(c.daily_price))}/hari
                                                    </span>
                                                )}
                                            </SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                                {errorsCreate.car_type && <p className="text-xs text-red-500">{errorsCreate.car_type}</p>}
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-1">
                                    <Label htmlFor="booking_date">Rent Date</Label>
                                    <Input
                                        id="booking_date"
                                        type="date"
                                        value={createData.booking_date}
                                        onChange={(e) => setCreateData('booking_date', e.target.value)}
                                        required
                                    />
                                </div>
                                <div className="space-y-1">
                                    <Label htmlFor="return_date">Return Date</Label>
                                    <Input
                                        id="return_date"
                                        type="date"
                                        value={createData.return_date}
                                        onChange={(e) => setCreateData('return_date', e.target.value)}
                                    />
                                </div>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-1">
                                    <Label htmlFor="payment_method">Payment Method</Label>
                                    <Select
                                        value={createData.payment_method}
                                        onValueChange={(val: any) => setCreateData('payment_method', val)}
                                    >
                                        <SelectTrigger>
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="Cash">Cash</SelectItem>
                                            <SelectItem value="Transfer">Transfer</SelectItem>
                                            <SelectItem value="DP">DP (Down Payment)</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div className="space-y-1">
                                    <Label htmlFor="payment_status">Payment Status</Label>
                                    <Select
                                        value={createData.payment_status}
                                        onValueChange={(val: any) => setCreateData('payment_status', val)}
                                    >
                                        <SelectTrigger>
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="Pending">Pending</SelectItem>
                                            <SelectItem value="Paid">Paid</SelectItem>
                                            <SelectItem value="Down Payment">Down Payment</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                            </div>

                            <div className="space-y-1">
                                <Label htmlFor="amount">Rental Price / Amount</Label>
                                <Input
                                    id="amount"
                                    type="number"
                                    min={0}
                                    value={createData.amount}
                                    onChange={(e) => setCreateData('amount', e.target.value)}
                                    placeholder="Pilih kendaraan untuk mengisi harga otomatis"
                                    required
                                />
                                {createData.car_type && (() => {
                                    const selected = readyCars.find(c => c.name === createData.car_type);
                                    if (!selected) return null;
                                    return (
                                        <p className="text-xs text-muted-foreground">
                                            Harga referensi —
                                            {selected.daily_price && <span className="ml-1">Harian: <strong>{new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(Number(selected.daily_price))}</strong></span>}
                                            {selected.weekly_price && <span className="ml-2">Mingguan: <strong>{new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(Number(selected.weekly_price))}</strong></span>}
                                            {selected.monthly_price && <span className="ml-2">Bulanan: <strong>{new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(Number(selected.monthly_price))}</strong></span>}
                                        </p>
                                    );
                                })()}
                            </div>

                            <DialogFooter className="pt-4">
                                <Button type="button" variant="outline" onClick={() => setIsCreateOpen(false)}>Cancel</Button>
                                <Button type="submit" disabled={processingCreate}>Save Booking</Button>
                            </DialogFooter>
                        </form>
                    </DialogContent>
                </Dialog>

                {/* ALLOCATION / ASSIGNMENT DIALOG */}
                <Dialog open={isAssignOpen} onOpenChange={setIsAssignOpen}>
                    <DialogContent className="max-w-md">
                        <DialogHeader>
                            <h2 className="text-lg font-semibold">Allocate Staff & Vehicle</h2>
                        </DialogHeader>
                        {selectedBooking && (
                            <form onSubmit={handleAssignSubmit} className="space-y-4 py-2">
                                <div className="rounded-lg bg-muted p-3 text-xs space-y-1">
                                    <div><span className="font-semibold">Customer:</span> {selectedBooking.customer?.name}</div>
                                    <div><span className="font-semibold">Requested Car Type:</span> {selectedBooking.car_type}</div>
                                </div>

                                <div className="space-y-1">
                                    <Label htmlFor="car_id">Assign Car Fleet</Label>
                                    <Select
                                        value={assignData.car_id}
                                        onValueChange={(val) => setAssignData('car_id', val)}
                                    >
                                        <SelectTrigger>
                                            <SelectValue placeholder="Choose a ready vehicle" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            {/* Show currently assigned car even if it is not ready, plus all other ready cars */}
                                            {selectedBooking.car && (
                                                <SelectItem value={selectedBooking.car_id!.toString()}>
                                                    {selectedBooking.car.name} ({selectedBooking.car.plate_number}) - [Current]
                                                </SelectItem>
                                            )}
                                            {readyCars
                                                .filter(c => c.id !== selectedBooking.car_id)
                                                .map((c) => (
                                                    <SelectItem key={c.id} value={c.id.toString()}>
                                                        {c.name} ({c.plate_number})
                                                    </SelectItem>
                                                ))}
                                        </SelectContent>
                                    </Select>
                                </div>

                                <div className="space-y-1">
                                    <Label htmlFor="peluncur_id">Assign Peluncur Officer (Field delivery)</Label>
                                    <Select
                                        value={assignData.peluncur_id}
                                        onValueChange={(val) => setAssignData('peluncur_id', val)}
                                    >
                                        <SelectTrigger>
                                            <SelectValue placeholder="Select Peluncur officer" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            {peluncurOfficers.map((p) => (
                                                <SelectItem key={p.id} value={p.id.toString()}>{p.name}</SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                </div>

                                <div className="space-y-1">
                                    <Label htmlFor="petugas_cuci_id">Assign Wash Officer (After return)</Label>
                                    <Select
                                        value={assignData.petugas_cuci_id}
                                        onValueChange={(val) => setAssignData('petugas_cuci_id', val)}
                                    >
                                        <SelectTrigger>
                                            <SelectValue placeholder="Select Wash officer" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            {washOfficers.map((w) => (
                                                <SelectItem key={w.id} value={w.id.toString()}>{w.name}</SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                </div>

                                <DialogFooter className="pt-4">
                                    <Button type="button" variant="outline" onClick={() => setIsAssignOpen(false)}>Cancel</Button>
                                    <Button type="submit" disabled={processingAssign}>Save Assignment</Button>
                                </DialogFooter>
                            </form>
                        )}
                    </DialogContent>
                </Dialog>

                <Dialog open={washConfirmId !== null} onOpenChange={(open) => !open && setWashConfirmId(null)}>
                    <DialogContent>
                        <DialogHeader>
                            <DialogTitle>Confirm Complete Wash</DialogTitle>
                        </DialogHeader>
                        <div className="py-4">
                            <p className="text-sm text-muted-foreground">
                                Are you sure you want to mark car washing as completed and set this car's availability to Ready?
                            </p>
                        </div>
                        <DialogFooter>
                            <Button variant="outline" onClick={() => setWashConfirmId(null)}>
                                Cancel
                            </Button>
                            <Button
                                onClick={() => {
                                    if (washConfirmId) {
                                        router.post(`/bookings/${washConfirmId}/wash`, {}, {
                                            onSuccess: () => setWashConfirmId(null)
                                        });
                                    }
                                }}
                            >
                                Complete Wash
                            </Button>
                        </DialogFooter>
                    </DialogContent>
                </Dialog>
            </div>
        </>
    );
}

BookingsIndex.layout = {
    breadcrumbs: [
        {
            title: 'Bookings',
            href: bookingsIndex(),
        },
    ],
};
