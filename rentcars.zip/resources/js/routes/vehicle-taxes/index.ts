import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\VehicleTaxController::index
 * @see app/Http/Controllers/VehicleTaxController.php:18
 * @route '/vehicle-taxes'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/vehicle-taxes',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\VehicleTaxController::index
 * @see app/Http/Controllers/VehicleTaxController.php:18
 * @route '/vehicle-taxes'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\VehicleTaxController::index
 * @see app/Http/Controllers/VehicleTaxController.php:18
 * @route '/vehicle-taxes'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\VehicleTaxController::index
 * @see app/Http/Controllers/VehicleTaxController.php:18
 * @route '/vehicle-taxes'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\VehicleTaxController::index
 * @see app/Http/Controllers/VehicleTaxController.php:18
 * @route '/vehicle-taxes'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\VehicleTaxController::index
 * @see app/Http/Controllers/VehicleTaxController.php:18
 * @route '/vehicle-taxes'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\VehicleTaxController::index
 * @see app/Http/Controllers/VehicleTaxController.php:18
 * @route '/vehicle-taxes'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\VehicleTaxController::store
 * @see app/Http/Controllers/VehicleTaxController.php:31
 * @route '/vehicle-taxes'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/vehicle-taxes',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\VehicleTaxController::store
 * @see app/Http/Controllers/VehicleTaxController.php:31
 * @route '/vehicle-taxes'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\VehicleTaxController::store
 * @see app/Http/Controllers/VehicleTaxController.php:31
 * @route '/vehicle-taxes'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\VehicleTaxController::store
 * @see app/Http/Controllers/VehicleTaxController.php:31
 * @route '/vehicle-taxes'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\VehicleTaxController::store
 * @see app/Http/Controllers/VehicleTaxController.php:31
 * @route '/vehicle-taxes'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\VehicleTaxController::update
 * @see app/Http/Controllers/VehicleTaxController.php:53
 * @route '/vehicle-taxes/{vehicle_tax}'
 */
export const update = (args: { vehicle_tax: number | { id: number } } | [vehicle_tax: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/vehicle-taxes/{vehicle_tax}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\VehicleTaxController::update
 * @see app/Http/Controllers/VehicleTaxController.php:53
 * @route '/vehicle-taxes/{vehicle_tax}'
 */
update.url = (args: { vehicle_tax: number | { id: number } } | [vehicle_tax: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { vehicle_tax: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { vehicle_tax: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    vehicle_tax: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        vehicle_tax: typeof args.vehicle_tax === 'object'
                ? args.vehicle_tax.id
                : args.vehicle_tax,
                }

    return update.definition.url
            .replace('{vehicle_tax}', parsedArgs.vehicle_tax.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\VehicleTaxController::update
 * @see app/Http/Controllers/VehicleTaxController.php:53
 * @route '/vehicle-taxes/{vehicle_tax}'
 */
update.put = (args: { vehicle_tax: number | { id: number } } | [vehicle_tax: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\VehicleTaxController::update
 * @see app/Http/Controllers/VehicleTaxController.php:53
 * @route '/vehicle-taxes/{vehicle_tax}'
 */
update.patch = (args: { vehicle_tax: number | { id: number } } | [vehicle_tax: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\VehicleTaxController::update
 * @see app/Http/Controllers/VehicleTaxController.php:53
 * @route '/vehicle-taxes/{vehicle_tax}'
 */
    const updateForm = (args: { vehicle_tax: number | { id: number } } | [vehicle_tax: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\VehicleTaxController::update
 * @see app/Http/Controllers/VehicleTaxController.php:53
 * @route '/vehicle-taxes/{vehicle_tax}'
 */
        updateForm.put = (args: { vehicle_tax: number | { id: number } } | [vehicle_tax: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\VehicleTaxController::update
 * @see app/Http/Controllers/VehicleTaxController.php:53
 * @route '/vehicle-taxes/{vehicle_tax}'
 */
        updateForm.patch = (args: { vehicle_tax: number | { id: number } } | [vehicle_tax: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\VehicleTaxController::destroy
 * @see app/Http/Controllers/VehicleTaxController.php:75
 * @route '/vehicle-taxes/{vehicle_tax}'
 */
export const destroy = (args: { vehicle_tax: number | { id: number } } | [vehicle_tax: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/vehicle-taxes/{vehicle_tax}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\VehicleTaxController::destroy
 * @see app/Http/Controllers/VehicleTaxController.php:75
 * @route '/vehicle-taxes/{vehicle_tax}'
 */
destroy.url = (args: { vehicle_tax: number | { id: number } } | [vehicle_tax: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { vehicle_tax: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { vehicle_tax: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    vehicle_tax: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        vehicle_tax: typeof args.vehicle_tax === 'object'
                ? args.vehicle_tax.id
                : args.vehicle_tax,
                }

    return destroy.definition.url
            .replace('{vehicle_tax}', parsedArgs.vehicle_tax.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\VehicleTaxController::destroy
 * @see app/Http/Controllers/VehicleTaxController.php:75
 * @route '/vehicle-taxes/{vehicle_tax}'
 */
destroy.delete = (args: { vehicle_tax: number | { id: number } } | [vehicle_tax: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\VehicleTaxController::destroy
 * @see app/Http/Controllers/VehicleTaxController.php:75
 * @route '/vehicle-taxes/{vehicle_tax}'
 */
    const destroyForm = (args: { vehicle_tax: number | { id: number } } | [vehicle_tax: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\VehicleTaxController::destroy
 * @see app/Http/Controllers/VehicleTaxController.php:75
 * @route '/vehicle-taxes/{vehicle_tax}'
 */
        destroyForm.delete = (args: { vehicle_tax: number | { id: number } } | [vehicle_tax: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const vehicleTaxes = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default vehicleTaxes