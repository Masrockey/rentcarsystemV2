<?php

use App\Models\Booking;
use App\Models\Car;
use App\Models\Customer;
use App\Models\User;

test('full rent car booking workflow', function () {
    // 1. Create a customer
    $customer = Customer::create([
        'name' => 'John Customer',
        'phone' => '0812345678',
        'email' => 'john@client.com',
        'address' => 'Customer Address',
    ]);

    // 2. Log in as Marketing to create a booking
    $marketing = User::factory()->create(['roles' => ['Marketing']]);
    $this->actingAs($marketing);

    $bookingData = [
        'customer_id' => $customer->id,
        'car_type' => 'Avanza',
        'booking_date' => '2026-07-12',
        'return_date' => '2026-07-15',
        'payment_method' => 'DP',
        'payment_status' => 'Down Payment',
        'amount' => 1500000,
    ];

    $response = $this->post(route('bookings.store'), $bookingData);
    $response->assertRedirect(route('bookings.index'));

    $booking = Booking::first();
    expect($booking->status)->toBe('Pending');
    expect($booking->car_id)->toBeNull();
    expect($booking->peluncur_id)->toBeNull();

    // 3. Log in as Admin to assign car, peluncur, and wash officer
    $admin = User::factory()->create(['roles' => ['Admin']]);
    $peluncur = User::factory()->create(['roles' => ['Peluncur']]);
    $cuci = User::factory()->create(['roles' => ['Petugas Cuci']]);
    $car = Car::create([
        'name' => 'Toyota Avanza',
        'year' => 2022,
        'plate_number' => 'B 9999 ZZZ',
        'status' => 'Ready',
    ]);

    $this->actingAs($admin);

    $assignData = [
        'car_id' => $car->id,
        'peluncur_id' => $peluncur->id,
        'petugas_cuci_id' => $cuci->id,
    ];

    $response = $this->put(route('bookings.update', $booking), $assignData);
    $response->assertRedirect(route('bookings.index'));

    $booking->refresh();
    expect($booking->status)->toBe('Confirmed'); // Auto-confirmed because car and peluncur are allocated
    expect($booking->car_id)->toBe($car->id);
    expect($booking->peluncur_id)->toBe($peluncur->id);
    expect($booking->petugas_cuci_id)->toBe($cuci->id);

    // 4. Log in as Peluncur to submit Delivery Checklist (Pengeluaran)
    $this->actingAs($peluncur);

    $deliveryData = [
        'checklist' => [
            'body' => true,
            'interior' => true,
            'fuel' => 'Full',
            'cleanliness' => 'Clean',
        ],
        'latitude' => '-6.2088',
        'longitude' => '106.8456',
        'notes' => 'Car handed over in perfect condition.',
    ];

    $response = $this->post(route('bookings.delivery', $booking), $deliveryData);
    $response->assertRedirect(route('bookings.index'));

    $booking->refresh();
    $car->refresh();

    expect($booking->status)->toBe('On Trip');
    expect($car->status)->toBe('Not Ready'); // Automatically changes to Not Ready
    expect($booking->delivery_latitude)->toBe('-6.2088');

    // 5. Log in as Peluncur to submit Return Checklist
    $returnData = [
        'checklist' => [
            'body' => true,
            'interior' => true,
            'fuel' => 'Full',
            'cleanliness' => 'Dirty',
        ],
        'notes' => 'Returned but muddy.',
    ];

    $response = $this->post(route('bookings.return', $booking), $returnData);
    $response->assertRedirect(route('bookings.index'));

    $booking->refresh();
    $car->refresh();

    expect($booking->status)->toBe('Returned');
    expect($car->status)->toBe('Belum Dicuci'); // Automatically changes to Belum Dicuci

    // 6. Log in as Petugas Cuci to complete washing
    $this->actingAs($cuci);

    $response = $this->post(route('bookings.wash', $booking));
    $response->assertRedirect(route('bookings.index'));

    $booking->refresh();
    $car->refresh();

    expect($booking->status)->toBe('Completed');
    expect($car->status)->toBe('Ready'); // Automatically changes to Ready
});
