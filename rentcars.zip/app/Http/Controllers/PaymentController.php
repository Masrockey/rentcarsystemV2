<?php

namespace App\Http\Controllers;

use App\Models\Booking;
use App\Models\Payment;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Inertia\Inertia;
use Inertia\Response;

class PaymentController extends Controller
{
    /**
     * Display a listing of payments.
     */
    public function index(): Response
    {
        return Inertia::render('payments/index', [
            'payments' => Payment::with('booking.customer')
                ->latest()
                ->get(),
            'bookings' => Booking::with('customer')
                ->orderBy('id', 'desc')
                ->get(['id', 'booking_number', 'customer_id']),
        ]);
    }

    /**
     * Store a newly created payment.
     */
    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'booking_id' => ['required', 'exists:bookings,id'],
            'payment_method' => ['required', 'string', Rule::in(['Cash', 'Transfer', 'DP'])],
            'dp_amount' => ['required', 'numeric', 'min:0'],
            'settlement_amount' => ['required', 'numeric', 'min:0'],
            'total_amount' => ['required', 'numeric', 'min:0'],
            'status' => ['required', 'string', Rule::in(['Pending', 'DP Dibayar', 'Lunas'])],
            'transfer_proof' => ['nullable', 'file', 'mimes:jpg,jpeg,png,pdf', 'max:5120'],
        ]);

        $transferProofPath = null;
        if ($request->hasFile('transfer_proof')) {
            $transferProofPath = $request->file('transfer_proof')->store('payments', 'public');
        }

        Payment::create([
            ...$validated,
            'invoice_number' => 'INV-'.strtoupper(Str::random(8)),
            'transfer_proof' => $transferProofPath,
        ]);

        Inertia::flash('toast', ['type' => 'success', 'message' => 'Payment recorded successfully.']);

        return to_route('payments.index');
    }

    /**
     * Update the specified payment.
     */
    public function update(Request $request, Payment $payment): RedirectResponse
    {
        $validated = $request->validate([
            'booking_id' => ['required', 'exists:bookings,id'],
            'payment_method' => ['required', 'string', Rule::in(['Cash', 'Transfer', 'DP'])],
            'dp_amount' => ['required', 'numeric', 'min:0'],
            'settlement_amount' => ['required', 'numeric', 'min:0'],
            'total_amount' => ['required', 'numeric', 'min:0'],
            'status' => ['required', 'string', Rule::in(['Pending', 'DP Dibayar', 'Lunas'])],
            'transfer_proof' => ['nullable', 'file', 'mimes:jpg,jpeg,png,pdf', 'max:5120'],
        ]);

        if ($request->hasFile('transfer_proof')) {
            $validated['transfer_proof'] = $request->file('transfer_proof')->store('payments', 'public');
        } else {
            unset($validated['transfer_proof']);
        }

        $payment->update($validated);

        Inertia::flash('toast', ['type' => 'success', 'message' => 'Payment updated successfully.']);

        return to_route('payments.index');
    }

    /**
     * Remove the specified payment.
     */
    public function destroy(Payment $payment): RedirectResponse
    {
        $payment->delete();

        Inertia::flash('toast', ['type' => 'success', 'message' => 'Payment deleted successfully.']);

        return to_route('payments.index');
    }
}
