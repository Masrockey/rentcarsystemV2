<?php

namespace App\Http\Controllers;

use App\Models\Booking;
use App\Models\Car;
use App\Models\Customer;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Support\Str;
use Inertia\Inertia;
use Inertia\Response;

class BookingController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request): Response
    {
        $user = $request->user();

        $query = Booking::with(['customer', 'car', 'peluncur', 'petugasCuci'])->latest();

        if (!$user->isAdmin() && !$user->isMarketing()) {
            if ($user->isPeluncur() && $user->isPetugasCuci()) {
                $query->where(function ($q) use ($user) {
                    $q->where('peluncur_id', $user->id)
                      ->orWhere('petugas_cuci_id', $user->id);
                });
            } elseif ($user->isPeluncur()) {
                $query->where('peluncur_id', $user->id);
            } elseif ($user->isPetugasCuci()) {
                $query->where('petugas_cuci_id', $user->id);
            }
        }

        return Inertia::render('bookings/index', [
            'bookings' => $query->get(),
            'customers' => Customer::orderBy('name')->get(),
            'cars' => Car::orderBy('name')->get(),
            'readyCars' => Car::where('status', 'Ready')->orderBy('name')->get(),
            'peluncurOfficers' => User::whereJsonContains('roles', 'Peluncur')->orderBy('name')->get(),
            'washOfficers' => User::whereJsonContains('roles', 'Petugas Cuci')->orderBy('name')->get(),
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'customer_id' => ['required', 'exists:customers,id'],
            'car_type' => ['required', 'string', 'max:255'],
            'booking_date' => ['required', 'date'],
            'return_date' => ['nullable', 'date', 'after_or_equal:booking_date'],
            'payment_method' => ['required', Rule::in(['Cash', 'Transfer', 'DP'])],
            'payment_status' => ['required', Rule::in(['Pending', 'Paid', 'Down Payment'])],
            'amount' => ['required', 'numeric', 'min:0'],
        ]);

        $bookingNumber = 'BK-' . date('Ymd') . '-' . strtoupper(Str::random(6));
        Booking::create($validated + [
            'booking_number' => $bookingNumber,
            'status' => 'Pending',
        ]);

        Inertia::flash('toast', [
            'type' => 'success',
            'message' => 'Booking created successfully.',
        ]);

        return to_route('bookings.index');
    }

    /**
     * Update the specified resource in storage. (Allocation / Assignment)
     */
    public function update(Request $request, Booking $booking): RedirectResponse
    {
        $validated = $request->validate([
            'car_id' => ['nullable', 'exists:cars,id'],
            'peluncur_id' => ['nullable', 'exists:users,id'],
            'petugas_cuci_id' => ['nullable', 'exists:users,id'],
            'payment_status' => ['nullable', Rule::in(['Pending', 'Paid', 'Down Payment'])],
            'status' => ['nullable', Rule::in(['Pending', 'Confirmed', 'On Trip', 'Returned', 'Completed'])],
        ]);

        $booking->update(array_filter($validated, fn ($val) => $val !== null));

        // If car and peluncur are assigned, auto-confirm booking if it was pending
        if ($booking->car_id && $booking->peluncur_id && $booking->status === 'Pending') {
            $booking->update(['status' => 'Confirmed']);
        }

        Inertia::flash('toast', [
            'type' => 'success',
            'message' => 'Booking assignment updated successfully.',
        ]);

        return to_route('bookings.index');
    }

    /**
     * Show checklist page for a specific booking.
     */
    public function showChecklist(Booking $booking): Response
    {
        $booking->load(['customer', 'car']);

        return Inertia::render('bookings/checklist', [
            'booking' => $booking,
        ]);
    }

    /**
     * Submit Delivery Checklist (Checklist Pengeluaran).
     */
    public function submitDelivery(Request $request, Booking $booking): RedirectResponse
    {
        $validated = $request->validate([
            'checklist' => ['required', 'array'],
            'latitude' => ['nullable', 'string'],
            'longitude' => ['nullable', 'string'],
            'notes' => ['nullable', 'string'],
        ]);

        $booking->update([
            'delivery_checklist' => $validated['checklist'],
            'delivery_latitude' => $validated['latitude'],
            'delivery_longitude' => $validated['longitude'],
            'delivery_notes' => $validated['notes'],
            'status' => 'On Trip',
        ]);

        // Automatically change car status to 'Not Ready'
        if ($booking->car) {
            $booking->car->update(['status' => 'Not Ready']);
        }

        Inertia::flash('toast', [
            'type' => 'success',
            'message' => 'Delivery checklist submitted. Car is now on trip.',
        ]);

        return to_route('bookings.index');
    }

    /**
     * Submit Return Checklist (Checklist Pengembalian).
     */
    public function submitReturn(Request $request, Booking $booking): RedirectResponse
    {
        $validated = $request->validate([
            'checklist' => ['required', 'array'],
            'notes' => ['nullable', 'string'],
        ]);

        $booking->update([
            'return_checklist' => $validated['checklist'],
            'return_notes' => $validated['notes'],
            'status' => 'Returned',
        ]);

        // Automatically change car status to 'Belum Dicuci'
        if ($booking->car) {
            $booking->car->update(['status' => 'Belum Dicuci']);
        }

        Inertia::flash('toast', [
            'type' => 'success',
            'message' => 'Return checklist submitted. Car requires washing.',
        ]);

        return to_route('bookings.index');
    }

    /**
     * Complete Washing Process.
     */
    public function completeWash(Booking $booking): RedirectResponse
    {
        $booking->update([
            'status' => 'Completed',
        ]);

        // Automatically change car status to 'Ready'
        if ($booking->car) {
            $booking->car->update(['status' => 'Ready']);
        }

        Inertia::flash('toast', [
            'type' => 'success',
            'message' => 'Car washing completed. Car status set to Ready.',
        ]);

        return to_route('bookings.index');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Booking $booking): RedirectResponse
    {
        $booking->delete();

        Inertia::flash('toast', [
            'type' => 'success',
            'message' => 'Booking deleted successfully.',
        ]);

        return to_route('bookings.index');
    }
}
